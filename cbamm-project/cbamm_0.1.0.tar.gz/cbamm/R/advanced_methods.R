
# CBAMM Advanced Meta-Analysis Methods
# Copy and paste the full code from the previous message here

ipd_meta_analysis <- function(data, outcome, treatment, covariates = NULL, 
                             study_id = "study", method = "one-stage") {
  # ... rest of the code
}

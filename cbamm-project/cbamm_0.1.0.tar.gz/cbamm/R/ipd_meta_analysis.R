
ipd_meta_analysis <- function(data, outcome, treatment, study_id = "study") {
  require(lme4)
  formula_str <- paste(outcome, "~", treatment, "+ (1|", study_id, ")")
  model <- lmer(as.formula(formula_str), data = data)
  return(list(model = model, effect = fixef(model)[treatment]))
}


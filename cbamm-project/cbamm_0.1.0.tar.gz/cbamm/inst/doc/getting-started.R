## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5,
  eval = FALSE
)

## ----eval=FALSE---------------------------------------------------------------
# # Install from CRAN (when available)
# # install.packages("cbamm")
# 
# # Load the package
# library(cbamm)

## ----eval=FALSE---------------------------------------------------------------
# # Load example data
# data(cumulative_example_data)
# 
# # Run cumulative meta-analysis
# result <- cumulative_meta_analysis(cumulative_example_data, order_by = "year")
# print(result)


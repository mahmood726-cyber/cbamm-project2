## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----load---------------------------------------------------------------------
# Load the package (use devtools::load_all() during development)
library(cbamm)
data(cumulative_example_data)
head(cumulative_example_data)

## ----basic--------------------------------------------------------------------
# Cumulative analysis ordered by publication year
result <- cumulative_meta_analysis(cumulative_example_data, order_by = "year")
print(result)

## ----plots, eval=FALSE--------------------------------------------------------
# # Plot cumulative estimates
# plot(result, type = "estimate")
# 
# # Plot confidence interval evolution
# plot(result, type = "ci")
# 
# # Plot precision evolution
# plot(result, type = "precision")
# 
# # Plot heterogeneity evolution
# plot(result, type = "heterogeneity")

## ----ordering-----------------------------------------------------------------
# Order by sample size (largest first)
result_size <- cumulative_meta_analysis(cumulative_example_data, 
                                       order_by = "sample_size", 
                                       order_direction = "descending")

# Order by precision
result_precision <- cumulative_meta_analysis(cumulative_example_data, 
                                            order_by = "precision")

## ----methods------------------------------------------------------------------
# Fixed effects
result_fixed <- cumulative_meta_analysis(cumulative_example_data, 
                                        order_by = "year", 
                                        method = "fixed")

# Bayesian
result_bayesian <- cumulative_meta_analysis(cumulative_example_data, 
                                           order_by = "year", 
                                           method = "bayesian")

